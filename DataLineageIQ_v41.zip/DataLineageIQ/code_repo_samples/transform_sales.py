"""
transform_sales.py
PySpark ETL: SALES data transformation pipeline
"""
from pyspark.sql import SparkSession
from pyspark.sql import functions as F

spark = SparkSession.builder.appName("SALES_ETL").getOrCreate()

# Load SALES from staging
df_sales = spark.sql("""
    SELECT
        id,
        to_date(created_date)                    AS created_date,
        UPPER(status)                             AS status_code,
        ROUND(revenue_amt, 2)                     AS revenue_amt,
        product_id,
        customer_id
    FROM STG_SALES_RAW
    WHERE status != 'CANCELLED'
""")

# Business rule: flag high-value orders
df_sales = df_sales.withColumn(
    "high_value_flag",
    F.when(F.col("revenue_amt") > 10000, "Y").otherwise("N")
)

# Write to DW
df_sales.write.mode("overwrite").insertInto("DW_SALES_FACT")
