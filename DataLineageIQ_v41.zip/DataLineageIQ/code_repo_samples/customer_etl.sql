-- ============================================================
-- load_customer_stg.sql
-- ETL Stage Load: SOURCE → STAGING
-- ============================================================
INSERT INTO STG_CUSTOMER_RAW (
    ID,
    CREATED_DATE,
    STATUS,
    CUSTOMER_NAME,
    EMAIL,
    REVENUE_AMT
)
SELECT
    src.CUST_ID                         AS ID,
    CAST(src.CREATE_TS AS TIMESTAMP)    AS CREATED_DATE,
    UPPER(src.CUST_STATUS)              AS STATUS,
    TRIM(src.FULL_NAME)                 AS CUSTOMER_NAME,
    LOWER(src.EMAIL_ADDR)               AS EMAIL,
    COALESCE(src.TOTAL_REVENUE, 0.00)   AS REVENUE_AMT
FROM SRC_CUSTOMER src
WHERE src.CUST_STATUS != 'DELETED'
  AND src.CREATE_TS >= DATEADD(DAY, -1, CURRENT_TIMESTAMP);

-- ============================================================
-- transform_customer_dw.sql
-- ETL Transform: STAGING → DATA WAREHOUSE
-- ============================================================
MERGE INTO DW_CUSTOMER_FACT tgt
USING (
    SELECT
        ID,
        DATE(CREATED_DATE)              AS CREATED_DATE,
        CASE STATUS
            WHEN 'ACTIVE'   THEN 'A'
            WHEN 'INACTIVE' THEN 'I'
            WHEN 'PENDING'  THEN 'P'
            ELSE 'U'
        END                             AS STATUS_CODE,
        CUSTOMER_NAME,
        EMAIL,
        REVENUE_AMT
    FROM STG_CUSTOMER_RAW
) src ON (tgt.ID = src.ID)
WHEN MATCHED THEN UPDATE SET
    tgt.STATUS_CODE   = src.STATUS_CODE,
    tgt.REVENUE_AMT   = src.REVENUE_AMT,
    tgt.UPDATED_DATE  = CURRENT_DATE
WHEN NOT MATCHED THEN INSERT (ID, CREATED_DATE, STATUS_CODE, CUSTOMER_NAME, EMAIL, REVENUE_AMT)
VALUES (src.ID, src.CREATED_DATE, src.STATUS_CODE, src.CUSTOMER_NAME, src.EMAIL, src.REVENUE_AMT);
