@echo off
title DataLineage IQ v4.1
color 0A
echo.
echo ============================================================
echo   DataLineage IQ v4.1
echo ============================================================

:: Kill old servers
for %%p in (8080 8090) do (
    for /f "tokens=5" %%a in ('netstat -aon 2^>nul ^| findstr ":%%p " ^| findstr "LISTENING"') do (
        taskkill /PID %%a /F >nul 2>&1
    )
)
timeout /t 2 >nul

:: Setup venv
if not exist "backend\venv" python -m venv backend\venv
call backend\venv\Scripts\activate.bat
pip install fastapi==0.111.0 "uvicorn[standard]==0.30.1" httpx==0.27.0 pydantic==2.7.1 python-multipart==0.0.9 reportlab==4.1.0 openpyxl==3.1.2 -q

:: ════════════════════════════════════════════════════════════
:: ERWIN DI CONFIGURATION
:: ════════════════════════════════════════════════════════════

:: Base URL — your ERWIN DI server
set ERWIN_BASE_URL=https://lpvra97a0104.wellsfargo.net:4512/erwinDISuite

:: API Key — from ERWIN DI Swagger UI (Authorization header value)
set ERWIN_API_KEY=

:: System Name — e.g. FNISH, HOGAN, FDR, CCHUB
:: If blank, the tool tries to detect it from the search query
set ERWIN_SYSTEM=

:: Environment Name — e.g. CDS_DCBTDISPUTE, PROD, UAT
set ERWIN_ENV=

:: Project IDs — optional, comma-separated
set ERWIN_PROJECT=

:: ════════════════════════════════════════════════════════════
:: OTHER SOURCE CONFIGURATION
:: ════════════════════════════════════════════════════════════
set LOCAL_META_DIR=%~dp0sample_data\metadata_files
set LOCAL_DICT_DIR=%~dp0sample_data\dictionary_files
set LOCAL_CODE_DIR=%~dp0sample_data\code_repo_samples

set TACHYON_URL=
set TACHYON_API_KEY=
set TACHYON_MODEL=tachyon-llm

echo.
echo [ERWIN] URL  : %ERWIN_BASE_URL%
echo [ERWIN] KEY  : %ERWIN_API_KEY:~0,8%...
echo [ERWIN] SYS  : %ERWIN_SYSTEM%
echo [ERWIN] ENV  : %ERWIN_ENV%
echo.
echo Starting on http://localhost:8090
echo.
timeout /t 2 >nul
start "" "http://localhost:8090"

cd backend
python -m uvicorn main:app --host 0.0.0.0 --port 8090 --reload
