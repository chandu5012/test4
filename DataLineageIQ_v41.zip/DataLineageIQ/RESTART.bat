@echo off
title DataLineage IQ — RESTART

echo.
echo ============================================================
echo   STEP 1: Killing old server on port 8080
echo ============================================================
for /f "tokens=5" %%a in ('netstat -aon 2^>nul ^| findstr ":8080 " ^| findstr "LISTENING"') do (
    echo Killing PID %%a ...
    taskkill /PID %%a /F >nul 2>&1
)
timeout /t 3 >nul
echo Done.

echo.
echo ============================================================
echo   STEP 2: Starting fresh server
echo ============================================================
call backend\venv\Scripts\activate.bat 2>nul
if errorlevel 1 (
    echo Installing dependencies first...
    python -m venv backend\venv
    call backend\venv\Scripts\activate.bat
    pip install -r backend\requirements.txt -q
)

echo.
echo Server starting at http://localhost:8080
echo After browser opens: press Ctrl+Shift+R to hard refresh
echo.
timeout /t 2 >nul
start "" http://localhost:8080

cd backend
python -m uvicorn main:app --host 0.0.0.0 --port 8080 --reload
