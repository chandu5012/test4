# DataLineage IQ v4.0 — Intelligent Data Lineage Platform

Award-winning data lineage discovery platform. Discovers complete end-to-end lineage across ERWIN DI, Data Dictionary, Code Repositories, and enriches everything with Tachyon AI.

---

## ⚡ Quick Start

```
Double-click START_APP.bat  →  opens http://localhost:8080
```

---

## 🔍 Source Fallback Chain

| Source | Priority 1 | Priority 2 | Priority 3 |
|--------|-----------|-----------|-----------|
| **ERWIN DI** | Live API (`ERWIN_BASE_URL`) | Local Excel/JSON (`LOCAL_META_DIR`) | Mock data |
| **Data Dictionary** | Live API (`DATA_DICT_URL`) | Local Excel/JSON (`LOCAL_DICT_DIR`) | Mock data |
| **Code Repo** | GitHub API (`GITHUB_TOKEN` + `GITHUB_REPO`) | Local folder scan (`LOCAL_CODE_DIR`) | Mock code |
| **Tachyon AI** | Internal LLM API (`TACHYON_URL`) | — | Disabled |

---

## 📂 Local File Formats Supported

### ERWIN DI — Metadata Files (`sample_data/metadata_files/`)

**JSON format** (ERWIN export or generic):
```json
{
  "objects": [
    { "id":"...", "name":"STG_TABLE", "objectType":"table", "systemName":"...",
      "databaseName":"...", "schemaName":"...",
      "columns": [{"name":"FIELD","dataType":"VARCHAR","description":"...","riskLevel":"High"}] }
  ],
  "relationships": [{"sourceId":"...","targetId":"...","type":"reads"}]
}
```

**Excel format** — any sheet with these headers (auto-detected):
```
SOURCE_TABLE | SOURCE_COLUMN | DATA_TYPE | TARGET_TABLE | TARGET_COLUMN | TRANSFORM_LOGIC | RISK_LEVEL | OWNER | DESCRIPTION | SYSTEM | DATABASE | SCHEMA
```

### Data Dictionary (`sample_data/dictionary_files/`)

**JSON format**:
```json
{
  "dictionary": [
    { "table":"TABLE","field":"COLUMN","dataType":"VARCHAR","description":"...",
      "riskLevel":"High","impact":"...","owner":"...","tags":["certified"],
      "businessRules":["NOT NULL","Must be > 0"] }
  ]
}
```

**Excel format** — headers: `FIELD | DATA_TYPE | DESCRIPTION | RISK_LEVEL | IMPACT | OWNER`

### Code Repository (`sample_data/code_repo_samples/`)
Any `.sql`, `.hql`, `.py`, `.java`, `.scala`, `.ksh`, `.sh`, `.xml`, `.yaml` files.

---

## 🤖 Tachyon AI Integration

Tachyon is used for:
1. **Code Summarisation** — Reads ETL code snippets and returns structured JSON:
   `{"summary":"...","key_rules":[...],"risk":"...","quality_score":7}`
2. **Executive Insights** — Governance briefing covering what the entity does and the top risk

API format tried (in order): OpenAI-compatible → Generic completion → Tachyon-native

```bash
# Example Tachyon call format (OpenAI-compatible)
POST /v1/chat/completions
{"model":"tachyon-llm","messages":[{"role":"user","content":"..."}],"max_tokens":400}
```

---

## 📊 Export Formats

| Export | Contents |
|--------|----------|
| **Excel** | 4 sheets: Metadata · Mapping Document · Lineage Graph · Summary |
| **JSON** | `lineage_graph` + `metadata` + `mapping_document` + `ai_insights` |
| **PDF** | Per-field impact report with business rules + Tachyon insights + risk matrix |

---

## 🎨 UI Features

- **ERD Flow View** — SQLflow-style rectangular cards with field rows, Bézier connectors, drag & drop
- **Force Graph View** — D3.js force simulation with node glow, tooltips, drill-down
- **3 Drill Levels** — System → Table → Field
- **Source Status Dots** — Live (green) / File (amber) / Mock (grey) / AI (purple)
- **AI Insights Panel** — Sidebar shows Tachyon executive summary
- **Export Row** — Excel + JSON buttons appear after every search

---

## ⚙️ Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `ERWIN_BASE_URL` | ERWIN DI API base URL | `http://erwin-di-host/erwin-di/api` |
| `ERWIN_API_KEY` | Bearer token | empty |
| `DATA_DICT_URL` | Data Dictionary API | `http://data-dict-host/api` |
| `LOCAL_META_DIR` | Local ERWIN fallback folder | `./sample_data/metadata_files` |
| `LOCAL_DICT_DIR` | Local dictionary folder | `./sample_data/dictionary_files` |
| `LOCAL_CODE_DIR` | Local code scan folder | `./sample_data/code_repo_samples` |
| `GITHUB_TOKEN` | GitHub personal access token | empty |
| `GITHUB_REPO` | GitHub repo (`owner/repo`) | empty |
| `TACHYON_URL` | Tachyon LLM API URL | empty |
| `TACHYON_API_KEY` | Tachyon API key | empty |
| `TACHYON_MODEL` | Model name | `tachyon-llm` |
