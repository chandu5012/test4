@echo off
title DataLineage IQ v4.1 - Update and Restart
color 0E

echo.
echo ================================================================
echo   DataLineage IQ v4.1 - UPDATE AND RESTART
echo ================================================================
echo.

:: Step 1: Kill ALL python/uvicorn processes on port 8080
echo [1/4] Stopping old server...
for /f "tokens=5" %%a in ('netstat -aon 2^>nul ^| findstr ":8080"') do (
    taskkill /PID %%a /F >nul 2>&1
)
taskkill /IM uvicorn.exe /F >nul 2>&1
taskkill /F /FI "WINDOWTITLE eq uvicorn*" >nul 2>&1
timeout /t 3 >nul
echo     Done - port 8080 cleared.

:: Step 2: Show current file
echo.
echo [2/4] Current frontend file info:
if exist "frontend\index.html" (
    echo     Found: frontend\index.html
    for %%F in (frontend\index.html) do echo     Size: %%~zF bytes
) else (
    echo     ERROR: frontend\index.html not found!
    pause & exit /b 1
)

:: Step 3: Setup venv
echo.
echo [3/4] Setting up Python environment...
if not exist "backend\venv" (
    python -m venv backend\venv
)
call backend\venv\Scripts\activate.bat
pip install fastapi uvicorn httpx pydantic python-multipart reportlab openpyxl -q

:: Step 4: Start with cache disabled
echo.
echo [4/4] Starting server (cache disabled)...
echo.
echo     URL: http://localhost:8080
echo     After browser opens: press Ctrl+Shift+R to force reload
echo.

set LOCAL_META_DIR=%~dp0sample_data\metadata_files
set LOCAL_DICT_DIR=%~dp0sample_data\dictionary_files
set LOCAL_CODE_DIR=%~dp0sample_data\code_repo_samples

timeout /t 2 >nul
start "" http://localhost:8080

cd backend
python -m uvicorn main:app --host 0.0.0.0 --port 8080 --reload --header "Cache-Control:no-cache"
