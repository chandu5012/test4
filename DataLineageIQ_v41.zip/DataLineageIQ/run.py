import os, sys, subprocess, time, webbrowser

PORT = 8090
print("=" * 55)
print("  DataLineage IQ v4.1")
print("=" * 55)

for port in [8080, 8090]:
    if sys.platform == "win32":
        os.system(f'for /f "tokens=5" %a in (\'netstat -aon ^| findstr ":{port} "\') do taskkill /PID %a /F 2>nul')
    else:
        os.system(f"fuser -k {port}/tcp 2>/dev/null || true")
time.sleep(2)

subprocess.call([sys.executable, "-m", "pip", "install",
    "fastapi==0.111.0", "uvicorn[standard]==0.30.1",
    "httpx==0.27.0", "pydantic==2.7.1",
    "python-multipart==0.0.9", "reportlab==4.1.0", "openpyxl==3.1.2",
    "-q", "--disable-pip-version-check"],
    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)), "backend"))
print(f"\nStarting on http://localhost:{PORT}\n")
time.sleep(1)
webbrowser.open(f"http://localhost:{PORT}")
subprocess.call([sys.executable, "-m", "uvicorn", "main:app",
    "--host", "0.0.0.0", "--port", str(PORT), "--reload"])
