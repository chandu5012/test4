-- ============================================================
-- Staging Load: STG_SALES_RAW
-- Schedule: Daily 02:00 UTC | Owner: Data Engineering
-- Source: Oracle SRC_SALES | Target: Snowflake STG_SALES_RAW
-- ============================================================

INSERT /*+ APPEND PARALLEL(8) */ INTO STG_SALES_RAW
  (SALE_ID, REVENUE_AMT, SALE_DATE, CUSTOMER_ID, REGION_CD, STATUS, LOAD_TS)
SELECT
  src.sale_id,
  NVL(src.revenue_amt, 0)                          AS REVENUE_AMT,
  TRUNC(src.sale_date)                              AS SALE_DATE,
  src.customer_id,
  UPPER(TRIM(NVL(src.region_cd, 'UNKNOWN')))        AS REGION_CD,
  CASE
    WHEN src.status = 'ACTIVE'   THEN 'ACTIVE'
    WHEN src.status = 'CLOSED'   THEN 'CLOSED'
    WHEN src.status = 'REFUNDED' THEN 'REFUNDED'
    ELSE 'PENDING'
  END                                               AS STATUS,
  SYSTIMESTAMP                                      AS LOAD_TS
FROM SRC_SALES src
WHERE src.status != 'DELETED'
  AND src.load_date >= TRUNC(SYSDATE) - 1
  AND NVL(src.revenue_amt, 0) >= 0;

COMMIT;
