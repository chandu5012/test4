"""
PySpark SCD Type 2 Transform — SALES
Schedule: Daily 03:00 UTC | Owner: Data Engineering
"""
from pyspark.sql import SparkSession, functions as F, Window

spark = SparkSession.builder.appName("SALES_Transform").getOrCreate()

# Load staging
stg = spark.table("STG_SALES_RAW")

# Business rules
df = (stg
  .filter(F.col("STATUS") != "DELETED")
  .withColumn("REVENUE_AMT",
    F.when(F.col("REVENUE_AMT") < 0, F.lit(0)).otherwise(F.col("REVENUE_AMT")))
  .withColumn("STATUS_CD",
    F.when(F.col("STATUS") == "ACTIVE",   F.lit("A"))
     .when(F.col("STATUS") == "CLOSED",   F.lit("C"))
     .when(F.col("STATUS") == "REFUNDED", F.lit("R"))
     .otherwise(F.lit("P")))
  .withColumn("SALE_DT", F.to_date("SALE_DATE"))
  .withColumn("REGION_CD", F.upper(F.trim(F.coalesce(F.col("REGION_CD"), F.lit("UNKNOWN")))))
  .dropDuplicates(["SALE_ID"])
)

# SCD Type 2 merge into DW_SALES_FACT
df.createOrReplaceTempView("stg_sales_clean")

spark.sql("""
MERGE INTO DW_SALES_FACT tgt
USING stg_sales_clean src ON tgt.SALE_ID = src.SALE_ID
WHEN MATCHED AND (tgt.REVENUE_AMT != src.REVENUE_AMT OR tgt.STATUS_CD != src.STATUS_CD) THEN
  UPDATE SET
    tgt.REVENUE_AMT = src.REVENUE_AMT,
    tgt.STATUS_CD   = src.STATUS_CD,
    tgt.SALE_DT     = src.SALE_DT,
    tgt.UPDATED_TS  = CURRENT_TIMESTAMP()
WHEN NOT MATCHED THEN
  INSERT (SALE_ID, REVENUE_AMT, STATUS_CD, SALE_DT, CUSTOMER_ID, REGION_CD, LOAD_TS)
  VALUES (src.SALE_ID, src.REVENUE_AMT, src.STATUS_CD, src.SALE_DT,
          src.CUSTOMER_ID, src.REGION_CD, CURRENT_TIMESTAMP())
""")
